import React from "react";
import { DataGrid } from "@mui/x-data-grid";
import { useEffect, useState } from "react";
import { getData } from "./data";


 const MyGrid = ()=> {
    const columns = [
        { field: 'Sl_no', headerName: 'Sl_no', width: 100, color: 'white' },
        { field: 'Business_code', headerName: 'Business_code', width: 150 },
        { field: 'Cust_number', headerName: 'Cust_number', width: 150 },
        { field: 'Clear_date', headerName: 'Clear_date', width: 100 },
        { field: 'Buisness_year', headerName: 'Buisness_year', width: 150 },
        { field: 'Doc_id', headerName: 'Doc_id', width: 100 },
        { field: 'Posting_date', headerName: 'Posting_date', width: 150 },
        { field: 'Document_create_date', headerName: 'Document_create_date', width: 175 },
        { field: 'Document_create_date1', headerName: 'Document_create_date1', width: 175, },
        { field: 'Due_in_date', headerName: 'Due_in_date', width: 150, },
        { field: 'Invoice_currency', headerName: 'Invoice_currency', width: 150, },
        { field: 'Document_type', headerName: 'Document_type', width: 150, },
        { field: 'Posting_id', headerName: 'Posting_id', width: 120, },
        { field: 'Area_business', headerName: 'Area_business', width: 150, },
        { field: 'Total_open_amount', headerName: 'Total_open_amount', width: 150, },
        { field: 'Baseline_create_date', headerName: 'Baseline_create_date', width: 175, },
        { field: 'Cust_payment_terms', headerName: 'Cust_payment_terms', width: 175, },
        { field: 'Invoice_id', headerName: 'Invoice_id', width: 150, },
        { field: 'IsOpen', headerName: 'IsOpen', width: 150, },
        { field: 'Aging_bucket', headerName: 'Aging_bucket', width: 150, },
        { field: 'Is_deleted', headerName: 'is_deleted', width: 150, }
    ]
    const [data, setdata] = useState([]);
    const [pageSize, setPageSize] = React.useState(10);
    const update = async () => setdata(await getData());
    useEffect(update, []);

 
    return (

        <div style={{ height: '600px', width: '100%', color: 'white' }}>
            
            <DataGrid
            
                columns={columns}
                classes={{ columnHeaderTitle: 'Datagrid', cellContent: 'Datagrid' }}
                rows={data}
                // pageSize={10}
                checkboxSelection
                getRowId={(data) => data.Sl_no}
                pageSize={pageSize}
                onPageSizeChange={(newPageSize) => setPageSize(newPageSize)}
                rowsPerPageOptions={[5, 10, 20, 30]}
                pagination/>
        </div>
    )
}
export default MyGrid;