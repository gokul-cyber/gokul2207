import React from 'react';
import abcproduct from './abcproduct.svg'
import logo from './logo.svg'
const Head = () => {
    return (
        <>
            <header className='head'>
                <section className='section1'>
                    <p id='sec1head'>

                        <span style={{marginTop:'40px'}} ><img src={abcproduct} id='abcproduct' alt='abcproductlogo' /></span>
                        <span style={{marginLeft:'380px'}} ><img src={logo} id='hrclogo' alt='hrclogo' /></span>
                       
                    </p>
                    {/* <p>INVOICE</p> */}


                </section>
                
            </header>
        </>
    )
}
export default Head;