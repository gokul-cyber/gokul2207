import './App.css';
import MyGrid from './components/MyGrid';
import Head from './components/Header';
import AddDialog from './components/AddDialog';

function App() {
  return (
    <>
    <Head/>
    {/* <span><AddDialog/></span> */}
     <MyGrid/>
     
    </>
      
   
  );
}

export default App;
